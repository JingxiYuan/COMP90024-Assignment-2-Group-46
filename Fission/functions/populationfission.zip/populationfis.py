from elasticsearch8 import Elasticsearch
import warnings
warnings.filterwarnings("ignore")
import requests
from flask import current_app

def config(k):
    with open(f'/configs/default/shared-data/{k}', 'r') as f:
        return f.read()

def main():
    # read in file 
    url='https://object-store.rc.nectar.org.au/v1/AUTH_dfd2b3ad91ca44f1bce756f3d8d50ec2/ccc_container/population_lga_2020.json'
    data = requests.get(url).json()

    # connect to elasticsearch address and port
    es = Elasticsearch('https://elasticsearch-master.elastic.svc.cluster.local:9200',
        verify_certs= False,
        basic_auth=(config('ES_USERNAME'), config('ES_PASSWORD')),
        timeout=300
    )
    
    # index_settings
    index_settings = {
        "settings": {
            "number_of_shards": 3,
            "number_of_replicas": 1
        },
        "mappings": {
            "properties": {
                "LGA_name": {
                    "type": "text"
                },
                "population": {
                    "type": "integer"
                },
                "age_group":{
                    "type": "text"
                },
                "gender": {
                    "type": "text"
                },
                "geometry": {
                    "type": "geo_shape"
                }
            }
        }
    }
    # create index
    index_name="population_fis"
    # delete index, when rerun the function 
    if es.indices.exists(index=index_name):
        es.indices.delete(index=index_name, ignore=[400, 404])
    
    es.indices.create(index=index_name, body=index_settings)
    index_list = es.cat.indices(format="json")
    info = [index for index in index_list if index["index"] == index_name]
    print(info)
    

    # input data 
    count=0
    for feature in data["features"]:
        geo=feature["geometry"]
        LGA_name=feature["properties"]["LGA_name_2020"]
        for property, population in feature["properties"].items():
            if property.startswith("F") :
                    count+=1
                    age_group=property[1:] 
                    
                    if property=="Females":
                        age_group="all_females"

                    document_data = {
                        "LGA_name": LGA_name,
                        "population": population,
                        "age_group": age_group,
                        "gender": "female",
                        "geometry": geo
                    }
                    
                    es.index(index=index_name, body=document_data)

            elif property.startswith("M"):
                    count+=1
                    age_group=property[1:] 

                    if property=="Males":
                        age_group="all_males"

                    document_data = {
                        "LGA_name": LGA_name,
                        "population": population,
                        "age_group": age_group,
                        "gender": "male",
                        "geometry": geo
                    }
                    
                    es.index(index=index_name, body=document_data)
        current_app.logger.info(f"{count} data inserted!")

    return "OK"



    
            

