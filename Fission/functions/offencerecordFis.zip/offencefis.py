from elasticsearch8 import Elasticsearch
import warnings
warnings.filterwarnings("ignore")
from openpyxl import load_workbook
from io import BytesIO
import urllib
from flask import current_app

def config(k):
    with open(f'/configs/default/shared-data/{k}', 'r') as f:
        return f.read()


def main():
    # get the data 
    url = 'https://object-store.rc.nectar.org.au/v1/AUTH_dfd2b3ad91ca44f1bce756f3d8d50ec2/ccc_container/LGA_Recorded_Offences_2023.xlsx'
    file = urllib.request.urlopen(url).read()
    wb = load_workbook(filename = BytesIO(file))
    sheet_names = wb.sheetnames
    sheet = wb[sheet_names[3]]


    # connect to elasticsearch address and port
    es = Elasticsearch("https://elasticsearch-master.elastic.svc.cluster.local:9200",
        verify_certs= False,
        basic_auth=(config('ES_USERNAME'), config('ES_PASSWORD')),
        timeout=300
    )
    
    # index_settings
    index_settings = {
        "settings": {
            "number_of_shards": 3,
            "number_of_replicas": 1
        },
        "mappings": {
            "properties": {
                "LGA_name": {
                    "type": "text"
                },
                "LGA_rate": {
                    "type": "float"
                },
                "offence_count":{
                    "type": "integer"
                },
                "offence_subdiv": {
                    "type": "text"
                },
                "year": {
                    "type": "date",
                    "format": "yyyy"
                }
            }
        }
    }
    # create index
    index_name="offence_record_fis"
    if es.indices.exists(index=index_name):
        es.indices.delete(index=index_name, ignore=[400, 404])

    es.indices.create(index=index_name, body=index_settings)
    index_list = es.cat.indices(format="json")
    info = [index for index in index_list if index["index"] == index_name]
    print(info)

    # Iterate over each row in the sheet
    for row in sheet.iter_rows(values_only=True):
        
        if row[0]==2019:
            break
    #('Year', 'Year ending', 'Police Service Area', 'Local Government Area', 'Offence Division', 
    #'Offence Subdivision', 'Offence Subgroup', 'Offence Count', 'PSA Rate per 100,000 population', 
    #'LGA Rate per 100,000 population')
        if row[0]!="Year":
            document_data = {
                        "LGA_name": row[3],
                        "LGA_rate": row[-1],
                        "offence_count": row[-3],
                        "offence_subdiv": row[5],
                        "year": row[0]
                    }
        
            es.index(index=index_name, body=document_data)
            current_app.logger.info('data inserted!')

    return "OK"


    